# CHANGELOG.md

## [2.0.3] - 2023-03-28

Fix video

## [2.0.2] - 2023-03-28

Add self-hosted video

## [2.0.1] - 2023-02-16

Remove header links

## [2.0.0] - 2023-02-16

Replace Cruip CSS with Tailwind CSS

## [1.0.0] - 2020-04-07

First release